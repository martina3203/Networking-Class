To stop the server from the server side, simply type 'stop'
Login is handled under the admin port, 8889.
LOGIN ADMIN PASSWORD PASSWORD

Threads do pause if there is too much money in the account but
you have to open a new connection to make it happen. Once another connection
changes the value of the account to an acceptable level, the transaction can continue.
I tested this using the test client given by the book and the telnet connection.
