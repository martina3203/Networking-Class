To stop the server from the server side, simply type 'stop'
Login is handled under the admin port, 8889.
LOGIN ADMIN PASSWORD PASSWORD